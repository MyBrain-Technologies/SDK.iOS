//
//  MBTSignalProcessingBridge.m
//  MyBrainTechnologiesSDK
//
//  Created by Baptiste Rasschaert on 15/09/2017.
//  Copyright © 2017 MyBrainTechnologies. All rights reserved.
//

#import "MBTSignalProcessingBridge.h"
#import "MBTBridgeConstants.h"

#include "MBT_Matrix.h" // use of the class MBT_Matrix
#include "MBT_MainQC.h" // use of the class MBT_Matrix
#include "MBT_ReadInputOrWriteOutput.h" // use of the class MBT_ReadInputOrWriteOutput

#include "MBT_PWelchComputer.h" // use of the class MBT_PWelchComputer
#include "MBT_Operations.h"

#include "MBT_BandPass_fftw3.h"

#include "MBT_FindClosest.h"
#include "MBT_ComputeSNR.h"
#include "MBT_ComputeCalibration.h"
#include "MBT_ComputeRelaxIndex.h"
#include "MBT_SmoothRelaxIndex.h"
#include "MBT_NormalizeRelaxIndex.h"
#include "MBT_RelaxIndexToVolum.h"
#include "MBT_PreProcessing.h"

#include "MBT_SNR_Stats.h"

#include "version.h"

/// Signal Processing Bridge helper methods,
/// to help converting format between C++ and Obj-C++.
@interface MBTSignalProcessingHelper: NSObject
extern const float IAFinf;
extern const float IAFsup;


+ (NSArray *)fromVectorToNSArray:(std::vector<float>) vector;
+ (NSArray *)fromMatrixToNSArray:(MBT_Matrix<float>) matrix;
+ (MBT_Matrix<float>)fromNSArrayToMatrix:(NSArray *)array
                               andHeight:(int)height
                                andWidth:(int)width;
+ (std::vector<float>)fromNSArraytoVector:(NSArray *)array;

+ (void)setCalibrationParameters:(std::map<std::string, std::vector<float>>) calibParameters;
+ (std::map<std::string, std::vector<float>>)getCalibrationParameters;
@end

@implementation MBTSignalProcessingHelper
static NSString* versionCPP = @VERSION;

const float IAFinf = 7;
const float IAFsup = 13;

static std::map<std::string, std::vector<float>> calibParams;

/// Converte *vector* to an Objective-C NSArray.
+ (NSArray *)fromVectorToNSArray:(std::vector<float>) vector {
    NSMutableArray * array = [[NSMutableArray alloc] init];
    for (int index = 0; index < int(vector.size()); index++)
    {
        NSNumber *data = [NSNumber numberWithFloat:vector[index]];
        [array addObject:data];
    }

    return (NSArray*) array;
}

/// Converte *MBT_Matrix* to an Objective-C NSArray.
+ (NSArray *)fromMatrixToNSArray:(MBT_Matrix<float>) matrix {
    NSMutableArray * array = [[NSMutableArray alloc] init];
    for (int index = 0; index < matrix.size().first; index++)
    {
        NSArray *vectorArray = [MBTSignalProcessingHelper fromVectorToNSArray:matrix.row(index)];
        [array addObject:vectorArray];
    }

    return (NSArray*) array;
}

/// Converte *NSArray* to *MBT_Matrix* format.
+ (MBT_Matrix<float>)fromNSArrayToMatrix:(NSArray *)array andHeight:(int)height andWidth:(int)width {
    MBT_Matrix<float> matrix = MBT_Matrix<float>((int) height, (int) width);

    for (int channelIndex = 0; channelIndex < height; channelIndex++)
    {
        for (int dataPoint = 0; dataPoint < width; dataPoint++)
        {
            matrix(channelIndex, dataPoint) = [array[channelIndex * width + dataPoint] floatValue];
        }
    }

    return matrix;
}

+ (std::vector<float>)fromNSArraytoVector:(NSArray *)array {
    std::vector<float> vector;
    
    for (int i = 0; i < (int)array.count; i++) {
        float arrayValue = [array[i] floatValue];
        vector.push_back(arrayValue);
    }
    
    return vector;
}

+ (void)setCalibrationParameters:(std::map<std::string, std::vector<float>>) calibParameters {
    calibParams = calibParameters;
}

+ (std::map<std::string, std::vector<float>>)getCalibrationParameters {
    return calibParams;
}

@end



//MARK: -
/// Quality Checker Bridge methods, for use in Swift.
@implementation MBTQualityCheckerBridge

/// Instance on *Main Quality Checker* to keep.
static MBT_MainQC *mainQC;

/// Initialize Main_QC, and save it.
+ (void)initializeMainQualityChecker:(float)sampRate
                             accuracy:(float)accuracy {
    // Construction de kppv
    unsigned int kppv = 19;

    // Construction de costClass
    MBT_Matrix<float> costClass(3,3);
    for (int t=0;t<costClass.size().first;t++)
    {
        for (int t1=0;t1<costClass.size().second;t1++)
        {
            if (t == t1)
            {
                costClass(t,t1) = 0;
            }
            else
            {
                costClass(t,t1) = 1;
            }
        }
    }
    
    // Construction de costClassBad
    MBT_Matrix<float> costClassBad(2,2);
    for (int t=0;t<costClass.size().first;t++)
    {
        for (int t1=0;t1<costClass.size().second;t1++)
        {
            if (t == t1)
            {
                costClass(t,t1) = 0;
            }
            else
            {
                costClass(t,t1) = 1;
            }
        }
    }

    // Construction de potTrainingFeatures
    std::vector< std::vector<float> > potTrainingFeatures;

    // Construction de dataClean
    std::vector< std::vector<float> > dataClean;

    // Init of Main_QC.
    mainQC = new MBT_MainQC(sampRate,
                            trainingFeatures,
                            trainingClasses,
                            w, mu, sigma, kppv,
                            costClass,
                            potTrainingFeatures,
                            dataClean,
                            spectrumClean,
                            cleanItakuraDistance,
                            accuracy,
                            trainingFeaturesBad,
                            trainingClassesBad,
                            wBad,muBad,sigmaBad,costClassBad);
    
}

/// Dealloc MBT_MainQC instance when session is finished, for memory safety.
+ (void)deInitializeMainQualityChecker {
    delete mainQC;
}

/// Method to compute Quality for a EEGPacket, for each channel.
+ (NSArray*) computeQuality: (NSArray*) signal
                   sampRate: (NSInteger) sampRate
                 nbChannels: (NSInteger) nbChannels
               nbDataPoints: (NSInteger) nbDataPoints
{

//    printf("Count Signal = %lu",[signal count]);
    // Transform EEG data into MBT_Matrix
    MBT_Matrix<float> signalMatrix = [MBTSignalProcessingHelper fromNSArrayToMatrix:signal
                                                                          andHeight:(int)nbChannels
                                                                           andWidth:(int)nbDataPoints];
    // Compute Quality
    mainQC->MBT_ComputeQuality(signalMatrix);
    // Getting the qualities in a cpp format
    std::vector<float> qualities = mainQC->MBT_get_m_quality();
    // Converting the qualities to an Objective-C format.
    return [MBTSignalProcessingHelper fromVectorToNSArray:qualities];
}

/// Method to get the modified EEG Data, according to the quality value.
+ (NSArray*) getModifiedEEGData {
    MBT_Matrix<float> modifiedData = mainQC->MBT_get_m_inputData();

    return [MBTSignalProcessingHelper fromMatrixToNSArray:modifiedData];
}

+ (NSString*) getVersion {
    return @VERSION;
}

@end

//MARK: -

/// Bridge methods for calibration calculation, for a group of
/// *MBTEEGPacket*.
@implementation MBTCalibrationBridge

/// Method to get the calibration dictionnary.
+ (NSDictionary *)computeCalibration: (NSArray *)modifiedChannelsData
                 qualities: (NSArray *)qualities
              packetLength: (NSInteger)packetLength
              packetsCount: (NSInteger)packetsCount
                  sampRate: (NSInteger)sampRate
{
    int height = (int)(qualities.count / packetsCount);
    
    // Put the modified EEG data in a matrix.
    MBT_Matrix<float> calibrationRecordings = [MBTSignalProcessingHelper fromNSArrayToMatrix:modifiedChannelsData
                                                                                   andHeight:height
                                                                                    andWidth:(int)(packetLength * packetsCount)];
    
    // Put the qualities in a matrix.
    MBT_Matrix<float> calibrationRecordingsQuality = [MBTSignalProcessingHelper fromNSArrayToMatrix:qualities
                                                                                          andHeight:height
                                                                                           andWidth:(int)packetsCount];
    
    // Set the thresholds for the outliers
//    // -----------------------------------
//    MBT_Matrix<float> Bounds(calibrationRecordings.size().first,2);
//    MBT_Matrix<float> Test(calibrationRecordings.size().first, calibrationRecordings.size().second);
//
//    for (int ch=0; ch<calibrationRecordings.size().first; ch++)
//    {
//        vector<float> signal_ch = calibrationRecordings.row(ch);
//
//        if (all_of(signal_ch.begin(), signal_ch.end(), [](double testNaN){return isnan(testNaN);}) )
//        {
//            errno = EINVAL;
//            perror("ERROR: BAD CALIBRATION - WE HAVE ONLY NAN VALUES");
//        }
//
//        // skip the NaN values in order to calculate the Bounds
//        vector<float>tmp_signal_ch = SkipNaN(signal_ch);
//
//        // find the bounds
//        vector<float> tmp_Bounds = CalculateBounds(tmp_signal_ch); // Set the thresholds for outliers
//        Bounds(ch,0) = tmp_Bounds[0];
//        Bounds(ch,1) = tmp_Bounds[1];
//
//        // basically, we convert from vector<float> to vector<double>
//        vector<double> CopySignal_ch(signal_ch.begin(), signal_ch.end());
//        vector<double> Copytmp_Bounds(tmp_Bounds.begin(), tmp_Bounds.end());
//
//        // set outliers to nan
//        vector<double> InterCopySignal_ch = MBT_OutliersToNan(CopySignal_ch, Copytmp_Bounds);
//        for (unsigned int t = 0 ; t < InterCopySignal_ch.size(); t++)
//            Test(ch,t) = (float) InterCopySignal_ch[t];
//    }
    
    // interpolate the nan values between the channels
//    MBT_Matrix<float> FullyInterpolatedTest = MBT_InterpolateBetweenChannels(Test);
    // interpolate the nan values across each channel
//    MBT_Matrix<float> InterpolatedAcrossChannels = MBT_InterpolateAcrossChannels(FullyInterpolatedTest);
    
    // Getting the map.
    std::map<std::string, std::vector<float>> paramCalib = MBT_ComputeCalibration(calibrationRecordings,
                                                                                   calibrationRecordingsQuality,
                                                                                   (int)sampRate,
                                                                                   (int)packetLength,
                                                                                   IAFinf,
                                                                                   IAFsup);
    
    // Save calibration parameters received.
    [MBTSignalProcessingHelper setCalibrationParameters:paramCalib];
    
    // Converting the parameters to an Obj-C format
    NSMutableDictionary * parametersDictionnary = [[NSMutableDictionary alloc] init];
    
    for (auto parameter: paramCalib)
    {
        NSString *parameterName = [NSString stringWithCString: parameter.first.c_str()
                                                     encoding:[NSString defaultCStringEncoding]];
        NSArray *parameterValue = [MBTSignalProcessingHelper fromVectorToNSArray:parameter.second];
        [parametersDictionnary setObject:parameterValue forKey:parameterName];
    }
    
    return parametersDictionnary;
}
    

@end


//MARK: - RelaxIndex

/// Bridge method to get the Relax Index
@implementation MBTRelaxIndexBridge

static vector<float>pastRelaxIndex;
static vector<float>smoothedRelaxIndex;
static vector<float>volume;
static vector<float>histFreq;

+ (float)computeRelaxIndex:(NSArray *)signal
                  sampRate:(NSInteger)sampRate
                nbChannels: (NSInteger) nbChannels
{
    int width = (int)(signal.count / nbChannels);
    MBT_Matrix<float> signalMatrix = [MBTSignalProcessingHelper fromNSArrayToMatrix:signal
                                                                          andHeight:(int)nbChannels
                                                                           andWidth:width];
    
    std::map<std::string, std::vector<float>> calibrationParams = [MBTSignalProcessingHelper getCalibrationParameters];
//    std::vector<float> calibrationParameters = calibrationParams["SNRCalib_ofBestChannel"];
    
    if (histFreq.size() == 0) {
        histFreq = calibrationParams["histFrequencies"];
    }
    
    float newVolum = main_relaxIndex(sampRate, calibrationParams, signalMatrix, histFreq, pastRelaxIndex, smoothedRelaxIndex, volume);

    return newVolum;
}
    
static float main_relaxIndex(const float sampRate, std::map<std::string, std::vector<float> > paramCalib,
                             const MBT_Matrix<float> &sessionPacket, std::vector<float> &histFreq, std::vector<float> &pastRelaxIndex, std::vector<float> &resultSmoothedSNR, std::vector<float> &resultVolum)
{
    
    std::vector<float> errorMsg = paramCalib["errorMsg"];
    std::vector<float> snrCalib = paramCalib["snrCalib"];
    
    // Session-----------------------------------
    float snrValue = MBT_ComputeRelaxIndex(sessionPacket, errorMsg, sampRate, IAFinf, IAFsup, histFreq);
    
    pastRelaxIndex.push_back(snrValue); // incrementation of pastRelaxIndex
    float smoothedRelaxIndex = MBT_SmoothRelaxIndex(pastRelaxIndex);
    float volum = MBT_RelaxIndexToVolum(smoothedRelaxIndex, snrCalib); // warning it's not the same inputs than previously
    
    //resultSmoothedSNR.assign(1,smoothedRelaxIndex);
    resultSmoothedSNR.push_back(smoothedRelaxIndex);
    
    //resultVolum.assign(1,volum);
    resultVolum.push_back(volum);
    // WARNING: If it's possible, I would like to save in the .json file, pastRelaxIndex and smoothedRelaxIndex (both)
    
    return volum;
}

+ (NSDictionary *) getSessionMetadata {
    NSMutableDictionary* dicoMetadata = [[NSMutableDictionary alloc]init];
    

    NSArray *parameterValue = [MBTSignalProcessingHelper fromVectorToNSArray:pastRelaxIndex];
    [dicoMetadata setObject:parameterValue forKey:@"rawRelaxIndexes"];
    
    parameterValue = [MBTSignalProcessingHelper fromVectorToNSArray:smoothedRelaxIndex];
    [dicoMetadata setObject:parameterValue forKey:@"smoothedRelaxIndex"];
    
    parameterValue = [MBTSignalProcessingHelper fromVectorToNSArray:volume];
    [dicoMetadata setObject:parameterValue forKey:@"volume"];
    
    parameterValue = [MBTSignalProcessingHelper fromVectorToNSArray:histFreq];
    [dicoMetadata setObject:parameterValue forKey:@"histFrequencies"];
    
    return dicoMetadata;
}

+(void) reinitRelaxIndex {
    pastRelaxIndex.clear();
    smoothedRelaxIndex.clear();
    volume.clear();
    histFreq.clear();
}

@end


//MARK: -

/// Bridge method for SNR Statistics
@implementation MBTSNRStatisticsBridge

+ (NSDictionary *)computeSessionStatistics:(NSArray *)inputDataSNR
                                 threshold:(float)threshold
{
    std::vector<float> inputDataVector = [MBTSignalProcessingHelper fromNSArraytoVector:inputDataSNR];
    SNR_Statistics statisticsObj = SNR_Statistics(inputDataVector);
    std::map<string, float> statisticsResults = statisticsObj.CalculateSNRStatistics(inputDataVector, threshold);
    
    // Converting the parameters to a NSDictionnary
    NSMutableDictionary * resultsDictionnary = [[NSMutableDictionary alloc] init];
    for (auto parameter: statisticsResults)
    {
        NSString *parameterName = [NSString stringWithCString: parameter.first.c_str()
                                                     encoding:[NSString defaultCStringEncoding]];
        NSNumber *parameterValue = [NSNumber numberWithFloat:parameter.second];
        [resultsDictionnary setObject:parameterValue forKey:parameterName];
    }
    
    return resultsDictionnary;
}

@end
